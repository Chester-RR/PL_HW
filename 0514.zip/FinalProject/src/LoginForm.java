import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.function.Consumer;

public class LoginForm extends JFrame {
	private JTextField emailField;
	private JPasswordField phoneField; // 保留原手機欄
	private JPasswordField passwordField; // 新增密碼欄
	private JButton loginButton;
	private JLabel messageLabel;
	private JTextField nameField;
	private Menu menu = new Menu();
	private static boolean successLogin = false;
	private Consumer<String> onSuccess; // 登录成功时把用户名传给主界面

	public LoginForm(Consumer<String> onSuccess) {
		this.onSuccess = onSuccess;
		setTitle("登入介面");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(350, 220);
		setLocationRelativeTo(null);
		setLayout(new GridLayout(6, 2, 10, 10)); // 調整為6行2列

		emailField = new JTextField();
		phoneField = new JPasswordField();
		passwordField = new JPasswordField(); // 初始化密碼欄
		loginButton = new JButton("登入");
		messageLabel = new JLabel("", SwingConstants.CENTER);

		add(new JLabel("Email："));
		add(emailField);
		add(new JLabel("手機號碼："));
		add(phoneField);
		add(new JLabel("使用者密碼：")); // 密碼標籤
		add(passwordField); // 密碼欄位
		add(new JLabel()); // 空白行
		add(loginButton);
		add(new JLabel());
		add(messageLabel);

		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = emailField.getText().trim();
				String phone = new String(phoneField.getPassword()).trim();
				String password = new String(passwordField.getPassword()).trim(); // 取得密碼

				if (email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
					messageLabel.setText("請填寫所有欄位");
					return;
				}

				String server = "jdbc:mysql://140.119.19.73:3315/";
				String database = "MG07";
				String url = server + database + "?useSSL=false&serverTimezone=UTC";
				String dbUsername = "MG07";
				String dbPassword = "D4NrtF";

				try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
					String sql = "SELECT * FROM user_info WHERE Email = ? AND PhoneNumber = ? AND Password = ?";
					try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
						pstmt.setString(1, email);
						pstmt.setString(2, phone);
						pstmt.setString(3, password); // 設定密碼參數
						ResultSet rs = pstmt.executeQuery();
						if (rs.next()) {
							String name = rs.getString("Name");
							successLogin = true;
							// 回调：
							onSuccess.accept(name);
							dispose();
						} else {
							messageLabel.setText("帳號、手機或密碼錯誤");
						}
					}
				} catch (SQLException ex) {
					ex.printStackTrace();
					messageLabel.setText("資料庫錯誤: " + ex.getMessage());
				}
			}
		});
	}

	public LoginForm() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new LoginForm().setVisible(false));
	}
}
