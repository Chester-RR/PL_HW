import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;

@SuppressWarnings("serial")
public class TaxiDetailFrame extends JFrame {
	// 資料庫連線參數
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";

	private final int groupID;
	private final int currentUserID;

	private final DefaultTableModel participantModel;
	private final JTable participantTable;
	private final DefaultListModel<String> commentListModel;
	private final JList<String> commentList;
	private final JTextField commentField;
	private final JButton addCommentButton;
	private final JButton joinButton = new JButton("加入行程Join");
	private final JButton leaveButton = new JButton("退出行程Quit");
	private final JButton dissolveButton = new JButton("解散行程Delete");

	public TaxiDetailFrame(int groupID, int currentUserID) {
		this.groupID = groupID;
		this.currentUserID = currentUserID;

		// 每 5 秒自動更新參與者與留言
		new Timer(5000, e -> {
			loadParticipantsFromDB();
			loadCommentsFromDB();
		}).start();

		setTitle("行程詳細 (Group " + groupID + ")");
		setSize(500, 600);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout(10, 10));

		// 1. 參與者表格 (NORTH)
		String[] cols = { "暱稱Name", "電話PhoneNumber", "Email" };
		participantModel = new DefaultTableModel(cols, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		participantTable = new JTable(participantModel);
		participantTable.setEnabled(false);
		JScrollPane partScroll = new JScrollPane(participantTable);
		partScroll.setPreferredSize(new Dimension(480, 120));
		add(partScroll, BorderLayout.NORTH);

		// 2. 留言列表 (CENTER)
		commentListModel = new DefaultListModel<>();
		commentList = new JList<>(commentListModel);
		JScrollPane commentScroll = new JScrollPane(commentList);
		commentScroll.setPreferredSize(new Dimension(480, 300));
		add(commentScroll, BorderLayout.CENTER);

		// 3. 底部：留言輸入區 and 操作按鈕區
		JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));

		// 留言輸入
		commentField = new JTextField();
		addCommentButton = new JButton("新增留言New Comments");
		JPanel commentInputPanel = new JPanel(new BorderLayout(5, 5));
		commentInputPanel.add(commentField, BorderLayout.CENTER);
		commentInputPanel.add(addCommentButton, BorderLayout.EAST);
		bottomPanel.add(commentInputPanel, BorderLayout.NORTH);

		// 操作按鈕
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
		leaveButton.setBackground(Color.RED);
		leaveButton.setForeground(Color.WHITE);
		dissolveButton.setBackground(Color.RED);
		dissolveButton.setForeground(Color.WHITE);
		buttonPanel.add(joinButton);
		buttonPanel.add(leaveButton);
		buttonPanel.add(dissolveButton);
		bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

		add(bottomPanel, BorderLayout.SOUTH);

		// 載入
		loadParticipantsFromDB();
		loadCommentsFromDB();

		// 顯示按鈕
		boolean isHost = checkIsHost();
		boolean isJoined = checkIsJoined();
		joinButton.setVisible(!isJoined && !isHost);
		leaveButton.setVisible(isJoined && !isHost);
		dissolveButton.setVisible(isHost);

		// 按鈕行為
		joinButton.addActionListener(e -> {
			performJoin();
			refreshState();
		});
		leaveButton.addActionListener(e -> {
			performLeave();
			refreshState();
		});
		dissolveButton.addActionListener(e -> {
			performDissolve();
			dispose();
		});
		addCommentButton.addActionListener(e -> {
			addCommentToDB();
			loadCommentsFromDB();
			commentField.setText("");
		});
	}

	private boolean checkIsJoined() {
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM connection WHERE groupID=? AND userID=?")) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private boolean checkIsHost() {
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn
						.prepareStatement("SELECT Host FROM connection WHERE groupID=? AND userID=?")) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() && rs.getBoolean("Host");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	// 加入行程
	private void performJoin() {
		// 1. 检查是否滿人、是否已加入
		if (checkIsJoined()) {
			JOptionPane.showMessageDialog(this, "您已經加入過此行程", "提示", JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS)) {
			// 检查是否滿人
			String sqlFull = "SELECT t.MaxPeople, COUNT(c.userID) AS cnt "
					+ "FROM taxi_Info t LEFT JOIN connection c ON t.groupID=c.groupID "
					+ "WHERE t.groupID=? GROUP BY t.MaxPeople";
			try (PreparedStatement ps = conn.prepareStatement(sqlFull)) {
				ps.setInt(1, groupID);
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next() && rs.getInt("cnt") >= rs.getInt("MaxPeople")) {
						JOptionPane.showMessageDialog(this, "此行程人數已滿", "提示", JOptionPane.WARNING_MESSAGE);
						return;
					}
				}
			}
			// 2. 加入成員
			String insertSql = "INSERT INTO connection (groupID, userID, Host) VALUES (?, ?, ?)";
			try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
				ps.setInt(1, groupID);
				ps.setInt(2, currentUserID);
				ps.setBoolean(3, false);
				ps.executeUpdate();
			}
			// 3. 刷新列表、按钮
			loadParticipantsFromDB();
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "加入失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	// 退出行程
	private void performLeave() {
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement("DELETE FROM connection WHERE groupID=? AND userID=?")) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "退出失敗: " + e.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
		loadParticipantsFromDB();
	}

	// 解散行程
	private void performDissolve() {
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS)) {
			// 1. 刪留言
			try (PreparedStatement ps = conn.prepareStatement("DELETE FROM taxi_comment WHERE groupID = ?")) {
				ps.setInt(1, groupID);
				ps.executeUpdate();
			}
			// 2. 刪 connection
			try (PreparedStatement ps = conn.prepareStatement("DELETE FROM connection WHERE groupID = ?")) {
				ps.setInt(1, groupID);
				ps.executeUpdate();
			}
			// 3. 刪行程
			try (PreparedStatement ps = conn.prepareStatement("DELETE FROM taxi_Info WHERE groupID = ?")) {
				ps.setInt(1, groupID);
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "解散失敗: " + e.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	// 刷新
	private void refreshState() {
		boolean isHost = checkIsHost();
		boolean isJoined = checkIsJoined();
		joinButton.setVisible(!isJoined && !isHost);
		leaveButton.setVisible(isJoined && !isHost);
		dissolveButton.setVisible(isHost);
		loadParticipantsFromDB();
		loadCommentsFromDB();
	}

	private void loadParticipantsFromDB() {
		String sql = "SELECT u.Name, u.PhoneNumber, u.Email, c.Host " + "FROM user_Info u JOIN connection c "
				+ "  ON u.userID = c.userID " + "WHERE c.groupID = ? " + "ORDER BY c.Host DESC, u.Name";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			try (ResultSet rs = ps.executeQuery()) {
				participantModel.setRowCount(0);
				while (rs.next()) {
					String name = rs.getString("Name");
					boolean isHost = rs.getBoolean("Host");
					if (isHost) {
						name += " (發起人Host)";
					}
					participantModel
							.addRow(new Object[] { name, "0" + rs.getString("PhoneNumber"), rs.getString("Email") });
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "載入參與者失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void loadCommentsFromDB() {
		String sql = "SELECT u.Name, c.commentText, c.createTime FROM taxi_comment c JOIN user_Info u "
				+ "ON c.userID = u.userID WHERE c.groupID = ? ORDER BY c.createTime";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ResultSet rs = ps.executeQuery();
			commentListModel.clear();
			while (rs.next()) {
				Timestamp tm = rs.getTimestamp("createTime");
				commentListModel.addElement(String.format("[%1$tF %1$tR] %2$s：%3$s", tm, rs.getString("Name"),
						rs.getString("commentText")));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "載入留言失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void addCommentToDB() {
		String txt = commentField.getText().trim();
		if (txt.isEmpty()) {
			JOptionPane.showMessageDialog(this, "留言不可留空", "提示", JOptionPane.WARNING_MESSAGE);
			return;
		}
		String sql = "INSERT INTO taxi_comment (groupID, userID, commentText) VALUES (?, ?, ?)";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			ps.setString(3, txt);
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "新增留言失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}
}
