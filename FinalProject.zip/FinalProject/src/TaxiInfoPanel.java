import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;

@SuppressWarnings("serial")
public class TaxiInfoPanel extends JPanel {
	private JTable table;
	private DefaultTableModel model;
	// 資料庫連線參數
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";
	private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	private boolean login = false;
	private int currentUserID = -1;

	public TaxiInfoPanel() {
		initUI();
		loadData();
		// 每 5 秒自動重新載入行程列表
		new Timer(5000, e -> loadData()).start();
	}

	private void initUI() {
		setLayout(new BorderLayout(5, 5));

		// 上方新增行程按鈕區
		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton addButton = new JButton("新增行程 New Journey");
		topPanel.add(addButton);
		add(topPanel, BorderLayout.NORTH);

		// 欄位名稱
		String[] columns = { "GroupID", "目前人數 / 最大人數", "平均每人價格 / 總價格", "預計出發時間", "詳細資訊" };
		model = new DefaultTableModel(columns, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 4;
			}
		};
		table = new JTable(model);
		table.setRowHeight(30);

		// 自訂「人數」欄位渲染：滿員顯示紅字「人數已滿」
		table.getColumn("目前人數 / 最大人數").setCellRenderer(new DefaultTableCellRenderer() {
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
				String text = value == null ? "" : value.toString();
				String[] parts = text.split("/");
				try {
					int curr = Integer.parseInt(parts[0]);
					int max = Integer.parseInt(parts[1]);
					if (curr >= max) {
						setText("人數已滿");
						setForeground(Color.RED);
					} else {
						setText(text);
						setForeground(Color.BLACK);
					}
				} catch (Exception e) {
					setText(text);
					setForeground(Color.BLACK);
				}
				return this;
			}
		});

		// 設定「詳細資訊」按鈕的 renderer & editor
		table.getColumn("詳細資訊").setCellRenderer(new ButtonRenderer());
		table.getColumn("詳細資訊").setCellEditor(new ButtonEditor(new JCheckBox()));

		add(new JScrollPane(table), BorderLayout.CENTER);

		// 新增行程按鈕動作
		addButton.addActionListener(event -> {
			if (!login) {
				JOptionPane.showMessageDialog(this, "請先登入才能新增行程", "未登入", JOptionPane.WARNING_MESSAGE);
			} else {
				new AddTaxiInfoFrame(currentUserID, this).setVisible(true);
			}
		});
	}

	public void changeState(boolean login, int userID) {
		this.login = login;
		this.currentUserID = userID;
	}

	public void loadData() {
		model.setRowCount(0);
		String sql = """
				SELECT t.groupID,
				       COALESCE(c.cnt, 0) AS PeopleNumber,
				       t.MaxPeople,
				       t.Money,
				       t.Time
				  FROM taxi_Info t
				  LEFT JOIN (
				      SELECT groupID, COUNT(DISTINCT userID) AS cnt
				        FROM connection
				       GROUP BY groupID
				  ) c ON t.groupID = c.groupID
				""";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				int groupID = rs.getInt("groupID");
				int current = rs.getInt("PeopleNumber");
				int max = rs.getInt("MaxPeople");
				int totalMoney = rs.getInt("Money");
				Timestamp ts = rs.getTimestamp("Time");
				String timeStr = TIME_FORMAT.format(ts);

				String peopleStr = current + "/" + max;
				String avgPerPerson = current > 0 ? String.valueOf(Math.round((double) totalMoney / current)) : "0";
				String priceStr = avgPerPerson + " / " + totalMoney;

				Object[] row = { groupID, peopleStr, priceStr, timeStr, "查看" };
				model.addRow(row);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "載入行程失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	// 按鈕渲染器
	private static class ButtonRenderer extends JButton implements TableCellRenderer {
		public ButtonRenderer() {
			setOpaque(true);
		}

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			setText(value == null ? "" : value.toString());
			return this;
		}
	}

	// 按鈕編輯器
	private class ButtonEditor extends DefaultCellEditor {
		private final JButton button = new JButton();
		private String label;

		public ButtonEditor(JCheckBox checkBox) {
			super(checkBox);
			button.setOpaque(true);
			button.addActionListener(e -> fireEditingStopped());
		}

		@Override
		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
				int column) {
			label = value == null ? "" : value.toString();
			button.setText(label);
			return button;
		}

		@Override
		public Object getCellEditorValue() {
			int row = table.getSelectedRow();
			if (!login) {
				JOptionPane.showMessageDialog(TaxiInfoPanel.this, "請先登入才能查看詳細資訊", "未登入", JOptionPane.WARNING_MESSAGE);
			} else {
				int groupID = (int) model.getValueAt(row, 0);
				new TaxiDetailFrame(groupID, currentUserID).setVisible(true);
			}
			return label;
		}
	}
}
