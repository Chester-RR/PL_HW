import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

@SuppressWarnings("serial")
public class AddTaxiInfoFrame extends JFrame {
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";

	private JTextField maxPeopleField;
	private JTextField moneyField;
	private JTextField timeField;
	private JButton submitButton;

	private TaxiInfoPanel parent;
	private int creatorUserID;

	public AddTaxiInfoFrame(int creatorUserID, TaxiInfoPanel parent) {
		this.creatorUserID = creatorUserID;
		this.parent = parent;

		setTitle("新增計程車行程");
		setSize(400, 250);
		setLocationRelativeTo(null);
		setLayout(new GridLayout(4, 2, 10, 10));

		// 最大人數
		add(new JLabel("最大人數MaxPeople："));
		maxPeopleField = new JTextField();
		add(maxPeopleField);

		// 預估總價格
		add(new JLabel("預估總價格TotalPrice："));
		moneyField = new JTextField();
		add(moneyField);

		// 預計出發時間
		add(new JLabel("預計出發時間DepartureTime："));
		timeField = new JTextField("2025-01-01 12:00:00");
		timeField.setForeground(Color.GRAY);
		timeField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (timeField.getText().equals("2025-01-01 12:00:00")) {
					timeField.setText("");
					timeField.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (timeField.getText().isEmpty()) {
					timeField.setText("2025-01-01 12:00:00");
					timeField.setForeground(Color.GRAY);
				}
			}
		});
		add(timeField);

		// 繳交按鈕
		submitButton = new JButton("繳交Submit");
		add(new JLabel());
		add(submitButton);

		submitButton.addActionListener(e -> submit());
	}

	private void submit() {
		String maxStr = maxPeopleField.getText().trim();
		String moneyStr = moneyField.getText().trim();
		String timeStr = timeField.getText().trim();

		if (maxStr.isEmpty() || moneyStr.isEmpty() || timeStr.isEmpty()) {
			JOptionPane.showMessageDialog(this, "請填寫所有欄位", "提示", JOptionPane.WARNING_MESSAGE);
			return;
		}

		int maxPeople;
		int money;
		try {
			maxPeople = Integer.parseInt(maxStr);
			money = Integer.parseInt(moneyStr);
		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "人數與價格格式錯誤", "格式錯誤", JOptionPane.ERROR_MESSAGE);
			return;
		}

		// ← 在這裡插入最大人數檢查
		if (maxPeople <= 1) {
			JOptionPane.showMessageDialog(this, "最大人數不能為小於 1 ，請輸入大於 1 的數字", "錯誤", JOptionPane.WARNING_MESSAGE);
			return;
		}
		// 檢查價格不能小於 1
		if (money < 1) {
			JOptionPane.showMessageDialog(this, "請輸入合理的價格", "錯誤", JOptionPane.WARNING_MESSAGE);
			return;
		}
		// 檢查出發時間
		Timestamp departure;
		try {
			departure = Timestamp.valueOf(timeStr);
		} catch (IllegalArgumentException ex) {
			JOptionPane.showMessageDialog(this, "時間格式錯誤，請輸入 yyyy-MM-dd HH:mm:ss", "格式錯誤", JOptionPane.ERROR_MESSAGE);
			return;
		}

		// 檢查出發時間不可早於現在
		Timestamp now = new Timestamp(System.currentTimeMillis());
		if (departure.before(now)) {
			JOptionPane.showMessageDialog(this, "出發時間不合理", "錯誤", JOptionPane.WARNING_MESSAGE);
			return;
		}
		String sqlMain = "INSERT INTO taxi_Info (PeopleNumber, MaxPeople, Money, Time) VALUES (?, ?, ?, ?)";
		String sqlLink = "INSERT INTO connection (groupID, userID, Host) VALUES (?, ?, ?)";

		int newGroupID = -1;
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sqlMain, Statement.RETURN_GENERATED_KEYS)) {
			ps.setInt(1, 1); // 初始人數
			ps.setInt(2, maxPeople);
			ps.setInt(3, money);
			ps.setTimestamp(4, Timestamp.valueOf(timeStr));
			ps.executeUpdate();

			try (ResultSet rs = ps.getGeneratedKeys()) {
				if (rs.next()) {
					newGroupID = rs.getInt(1);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "新增行程失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
			return;
		}

		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement linkPs = conn.prepareStatement(sqlLink)) {
			linkPs.setInt(1, newGroupID);
			linkPs.setInt(2, creatorUserID);
			linkPs.setBoolean(3, true); // 這裡把 Host 設為 true

			linkPs.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "加入發起人失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
			return;
		}

		parent.loadData();
		JOptionPane.showMessageDialog(this, "新增成功Success（GroupID=" + newGroupID + "）", "Info",
				JOptionPane.INFORMATION_MESSAGE);
		dispose();
	}
}
