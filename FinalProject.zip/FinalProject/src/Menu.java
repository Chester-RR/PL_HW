import javax.swing.*;
import java.sql.*;
import java.awt.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.function.IntConsumer;

public class Menu {
	private static int currentUserID = -1; // 登入後的 userID
	private static String currentUserName = null;
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=UTC";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";
// 登入後的使用者名稱

	private static RegisterForm registerForm = new RegisterForm();

	private static JPanel perInfo = new JPanel(new BorderLayout());

	private static JLabel timeLabel = new JLabel();
	private static JPanel buttonPanel = new JPanel();
	private static JButton buttonLogin = new JButton("登入Login");
	private static JButton buttonRegister = new JButton("註冊Register");
	private static TaxiInfoPanel taxiinfopanel;

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			taxiinfopanel = new TaxiInfoPanel();

			JFrame frame = new JFrame("政大公車 & 計程車系統");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(1000, 800);
			frame.setLayout(new BorderLayout());

			setupPerInfo();
			frame.add(perInfo, BorderLayout.NORTH);

			// ======= 北部：時間區塊（已含於 BusinfoPanel） =======
			BusInfoPanel busInfo = new BusInfoPanel();
			busInfo.setPreferredSize(new Dimension(1000, 30));
			JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, busInfo, taxiinfopanel);
			splitPane.setDividerLocation(400);
//			splitPane.setResizeWeight(0.7);
			frame.add(splitPane, BorderLayout.CENTER);
			frame.setVisible(true);
			// 每 10 秒檢查並刪除 60 分鐘前已出發的行程及其留言
			new Timer(10000, e -> {
				new SwingWorker<Void, Void>() {
					@Override
					protected Void doInBackground() throws Exception {
						try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS)) {
							// 1. 刪除所有過期行程的留言
							String deleteCommentsSql = "DELETE c FROM taxi_comment c "
									+ "JOIN taxi_Info t ON c.groupID = t.groupID "
									+ "WHERE t.Time <= DATE_SUB(NOW(), INTERVAL 60 MINUTE)";
							try (PreparedStatement ps = conn.prepareStatement(deleteCommentsSql)) {
								ps.executeUpdate();
							}

							// 2. 刪除過期行程
							String deleteTripsSql = "DELETE FROM taxi_Info "
									+ "WHERE Time <= DATE_SUB(NOW(), INTERVAL 60 MINUTE)";
							try (PreparedStatement ps = conn.prepareStatement(deleteTripsSql)) {
								ps.executeUpdate();
							}
						}
						return null;
					}

					@Override
					protected void done() {
						// 刪完之後更新行程列表
						taxiinfopanel.loadData();
					}
				}.execute();
			}).start();
		});
	}

	private static void setupPerInfo() {
		// 現在時間
		LocalTime now = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		timeLabel.setText(now.format(formatter));
		Timer clockTimer = new Timer(1000, e -> timeLabel.setText(LocalTime.now().format(formatter)));
		clockTimer.start();

		// 左側時間標籤
		JLabel labInfo = new JLabel("現在時間 (Current Time) : ");
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		leftPanel.add(labInfo);
		leftPanel.add(timeLabel);
		labInfo.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		timeLabel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		// 右側登入註冊
		buttonPanel.add(buttonRegister);
		buttonPanel.add(buttonLogin);

		perInfo.add(leftPanel, BorderLayout.WEST);
		perInfo.add(buttonPanel, BorderLayout.EAST);

		LoginForm loginForm = new LoginForm((IntConsumer) userID -> {
			currentUserID = userID;
			currentUserName = fetchUserName(userID);
			taxiinfopanel.changeState(true, currentUserID);
			showWelcome(currentUserName);
		});

		buttonLogin.addActionListener(e -> loginForm.setVisible(true));
		buttonRegister.addActionListener(e -> registerForm.setVisible(true));
	}

	private static String fetchUserName(int userID) {
		String sql = "SELECT Name FROM user_Info WHERE userID = ?";
		String name = "";

		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, userID);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					name = rs.getString("Name");
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return name;
	}

	private static void showWelcome(String name) {
		// 1. 建立 infoPanel
		JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		JLabel welcomeLabel = new JLabel("HELLO，" + name + " 歡迎使用約車服務");
		welcomeLabel.setFont(new Font("微軟正黑體", Font.ITALIC, 15));
		infoPanel.add(welcomeLabel);

		// 2. 建立登出按鈕
		JButton logoutButton = new JButton("登出Logout");
		logoutButton.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
		logoutButton.addActionListener(e -> {
			// 清除登入狀態
			currentUserID = -1;
			currentUserName = null;
			taxiinfopanel.changeState(false, -1);
			// 移除歡迎面板，顯示原本的「登入／註冊」按鈕
			perInfo.remove(infoPanel);
			buttonPanel.setVisible(true);

			// 重新整理 UI
			perInfo.revalidate();
			perInfo.repaint();
		});
		infoPanel.add(logoutButton);

		// 3. 隱藏原有的按鈕列，改顯示 infoPanel
		buttonPanel.setVisible(false);
		perInfo.add(infoPanel, BorderLayout.EAST);
	}

}
