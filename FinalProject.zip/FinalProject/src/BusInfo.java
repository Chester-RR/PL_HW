  import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import java.awt.*;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

@SuppressWarnings("serial")
public class BusInfo extends JFrame {

    public BusInfo() {
        setTitle("台北公車地圖連結");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 600);
        setLocationRelativeTo(null); // 視窗置中

        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setEditable(false);
        textPane.setText(buildHtmlContent());

        textPane.addHyperlinkListener(e -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                try {
                    Desktop.getDesktop().browse(new URI(e.getURL().toString()));
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        add(new JScrollPane(textPane));
    }

    private String buildHtmlContent() {
//        System.out.println("目前工作目錄：" + System.getProperty("user.dir"));

        try (FileReader reader = new FileReader("./src/bus_url.json")) {
            Gson gson = new Gson();
            java.lang.reflect.Type type = new TypeToken<Map<String, Map<String, String>>>() {}.getType();
            Map<String, Map<String, String>> data = gson.fromJson(reader, type);

            StringBuilder html = new StringBuilder();
            html.append("<html><body style='font-family: Microsoft JhengHei, sans-serif;'>");

            for (String station : data.keySet()) {
                html.append("<h2 style='color:#2E86C1;'>").append(station).append("</h2>");
                html.append("<table border='1' cellpadding='8' cellspacing='0' style='border-collapse: collapse; width: 100%;'>");
                html.append("<thead style='background-color: #D6EAF8;'>");
                html.append("<tr><th style='text-align:left;'>路線名稱</th><th style='text-align:left;'>連結</th></tr>");
                html.append("</thead><tbody>");

                Map<String, String> stops = data.get(station);
                for (String routeName : stops.keySet()) {
                    String url = stops.get(routeName);
                    html.append("<tr>");
                    html.append("<td>").append(routeName).append("</td>");
                    html.append("<td><a href='").append(url).append("' style='color:#2874A6;'>")
                        .append(url).append("</a></td>");
                    html.append("</tr>");
                }

                html.append("</tbody></table><br/>");
            }

            html.append("</body></html>");
            return html.toString();

        } catch (IOException e) {
            e.printStackTrace();
            return "<html><body><p style='color:red;'>載入 bus_url.json 失敗。</p></body></html>";
        }
    }

    // 如果你仍想保留 main 方法測試用，可以這樣寫：
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BusInfo().setVisible(true);
        });
    }
}