import javax.swing.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.function.IntConsumer;

public class Menu {
	private static int currentUserID = -1; // 登入後的 userID
	private static String currentUserName = null;
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=UTC";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";
// 登入後的使用者名稱

	private static JButton[] buttons = new JButton[3];
	private static JTable table;
	private static RegisterForm registerForm = new RegisterForm();
	private static DefaultTableModel[] models = new DefaultTableModel[3];
	private static JPanel upperPanel = new JPanel(new GridLayout(3, 1));
	private static JPanel underPanel = new JPanel(new GridLayout(2, 1));
	private static JPanel perInfo = new JPanel(new BorderLayout());
	private static JLabel labInfo = new JLabel("現在時間 (Current Time) : ");
	private static JLabel label = new JLabel("尚無最新消息");
	private static JLabel timeLabel = new JLabel();
	private static JPanel buttonPanel = new JPanel();
	private static JButton buttonLogin = new JButton("登入");
	private static JButton buttonRegister = new JButton("註冊");
	private static TaxiInfoPanel taxiinfopanel; // 構造時再初始化

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			// 初始化 TaxiInfoPanel，傳入 currentUserID
			taxiinfopanel = new TaxiInfoPanel();

			JFrame frame = new JFrame("政大公車系統");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(1000, 1000);
			frame.setLayout(new BorderLayout());

			// 時鐘
			LocalTime now = LocalTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
			timeLabel.setText(now.format(formatter));
			Timer clockTimer = new Timer(1000, e -> timeLabel.setText(LocalTime.now().format(formatter)));
			clockTimer.start();

			// 個人資訊區
			perInfo.add(labInfo, BorderLayout.WEST);
			perInfo.add(timeLabel, BorderLayout.CENTER);
			setupPerInfo();
			upperPanel.add(perInfo);
			upperPanel.add(label);

			// 公車選單按鈕
			JPanel btnPanel = new JPanel(new GridLayout(1, 3));
			String[] btnNames = { "台北車站", "捷運動物園站", "捷運市政府站" };
			for (int i = 0; i < btnNames.length; i++) {
				int idx = i;
				buttons[i] = new JButton(btnNames[i]);
				buttons[i].setFocusPainted(false);
				buttons[i].setBorderPainted(false);
				buttons[i].setContentAreaFilled(false);
				buttons[i].setOpaque(true);
				buttons[i].setFont(new Font("SansSerif", Font.BOLD, 16));
				buttons[i].addActionListener(e -> switchTable(idx));
				btnPanel.add(buttons[i]);
			}
			upperPanel.add(btnPanel);
			frame.add(upperPanel, BorderLayout.NORTH);

			// 樣板資料
			String[] cols = { "公車類別", "時間", "路線連結" };
			models[0] = new DefaultTableModel(new Object[][] { { "113", 60, 10 }, { "566", 20, 10 } }, cols);
			models[1] = new DefaultTableModel(new Object[][] { { "622", 5, 10 }, { "142", 15, 10 } }, cols);
			models[2] = new DefaultTableModel(new Object[][] { { "321", 5, 10 }, { "654", 10, 10 } }, cols);

			table = new JTable(models[0]);
			switchTable(0);

			underPanel.add(new JScrollPane(table));
			underPanel.add(taxiinfopanel);
			frame.add(underPanel, BorderLayout.CENTER);

			LatestNews();
			frame.setVisible(true);
		});
	}

	private static void setupPerInfo() {
		buttonPanel.add(buttonRegister);
		buttonPanel.add(buttonLogin);
		perInfo.add(buttonPanel, BorderLayout.EAST);

		// 使用 IntConsumer 接收 userID
		LoginForm loginForm = new LoginForm((IntConsumer) userID -> {
			currentUserID = userID;
			currentUserName = fetchUserName(userID);
			taxiinfopanel.changeState(true, currentUserID);
			showWelcome(currentUserName);
		});
		buttonLogin.addActionListener(e -> loginForm.setVisible(true));
		buttonRegister.addActionListener(e -> registerForm.setVisible(true));
	}

	private static String fetchUserName(int userID) {
		String sql = "SELECT Name FROM user_Info WHERE userID = ?";
		String name = "";

		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setInt(1, userID);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					name = rs.getString("Name");
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// 如果需要可以改成拋例外或顯示錯誤對話框
		}

		return name;
	}

	private static void showWelcome(String name) {
		JPanel infoPanel = new JPanel();
		JLabel welcomeLabel = new JLabel("哈囉，" + name + " 歡迎使用約車服務");
		welcomeLabel.setFont(new Font("微軟正黑體", Font.ITALIC, 15));
		infoPanel.add(welcomeLabel);
		buttonPanel.setVisible(false);
		perInfo.add(infoPanel, BorderLayout.EAST);
	}

	private static void LatestNews() {
		String text = "";
		for (int i = 0; i < models.length; i++) {
			DefaultTableModel model = models[i];
			if (model.getRowCount() > 0) {
				int time = (int) model.getValueAt(0, 1);
				if (time >= 10) {
					text += (i == 0 ? "台北車站" : i == 1 ? "捷運動物園站" : "捷運市政府站") + " ";
				}
			}
		}
		if (text.isEmpty()) {
			text = "2025雙北世界壯年運動會 2025.5.17-30   2025 Taipei & New Taipei City World Masters Games May 17–30";
			label.setForeground(Color.BLACK);
		} else {
			label.setText("--------------------------------將抵達公車的方向為 : " + text);
			label.setForeground(Color.RED);
		}
		label.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		Timer timer = new Timer(500, e -> {
			String finalText = label.getText();
			int index = (int) (System.currentTimeMillis() / 500 % finalText.length());
			String movingText = finalText.substring(index) + finalText.substring(0, index);
			label.setText(movingText);
		});
		timer.start();
	}

	private static void switchTable(int index) {
		table.setModel(models[index]);
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setForeground(i == index ? Color.BLUE : Color.BLACK);
			buttons[i].setBackground(i == index ? new Color(173, 216, 230) : Color.WHITE);
		}
	}
}
