import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TaxiInfoPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    // 資料庫連線參數
    private static final String URL =
    	    "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";

    private static final String DB_USER = "MG07";
    private static final String DB_PASS = "D4NrtF";

    private boolean login = false;
    private int currentUserID = -1;

    public TaxiInfoPanel() {
        initUI();
        loadData();
    }

    private void initUI() {
        setLayout(new BorderLayout(5,5));

        // 上方按鈕：新增行程
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("新增行程");
        topPanel.add(addButton);
        add(topPanel, BorderLayout.NORTH);

        // 表格
        String[] columns = { "GroupID", "目前人數", "價格", "預計出發時間" };
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 選中一列 → 開啟詳細
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int groupID = Integer.parseInt(model.getValueAt(table.getSelectedRow(), 0).toString());
                TaxiDetailFrame detailFrame = new TaxiDetailFrame(groupID, currentUserID);
                detailFrame.setVisible(true);
            }
        });

        // 新增行程按鈕
        addButton.addActionListener(event -> {
            if (!login) {
                JOptionPane.showMessageDialog(
                    this,
                    "請先登入才能新增行程",
                    "未登入",
                    JOptionPane.WARNING_MESSAGE
                );
            } else {
                new AddTaxiInfoFrame(currentUserID, this).setVisible(true);
            }
        });
    }

    /**
     * 更新登入狀態及 userID
     */
    public void changeState(boolean login, int userID) {
        this.login = login;
        this.currentUserID = userID;
    }

    /**
     * 從資料庫撈取行程並更新表格
     */
    public void loadData() {
        model.setRowCount(0);
        String sql = """
            SELECT t.groupID,
                   COALESCE(c.cnt, 0) AS PeopleNumber,
                   t.Money,
                   t.Time
              FROM taxi_Info t
              LEFT JOIN (
                  SELECT groupID, COUNT(DISTINCT userID) AS cnt
                    FROM connection
                   GROUP BY groupID
              ) c ON t.groupID = c.groupID
            """;

        try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Object[] row = {
                    rs.getInt("groupID"),
                    rs.getInt("PeopleNumber"),
                    rs.getInt("Money"),
                    rs.getTimestamp("Time")
                };
                model.addRow(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "載入行程失敗: " + ex.getMessage(),
                "錯誤",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

}
