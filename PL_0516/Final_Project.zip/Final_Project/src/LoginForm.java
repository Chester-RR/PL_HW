import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.function.IntConsumer;

public class LoginForm extends JFrame {
    private JTextField emailField;
    private JPasswordField phoneField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel messageLabel;
    private IntConsumer onSuccess;  // 登入成功時傳遞 userID

    public LoginForm(IntConsumer onSuccess) {
        this.onSuccess = onSuccess;
        setTitle("登入介面");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 2, 10, 10));

        emailField = new JTextField();
        phoneField = new JPasswordField();
        passwordField = new JPasswordField();
        loginButton = new JButton("登入");
        messageLabel = new JLabel("", SwingConstants.CENTER);

        add(new JLabel("Email："));
        add(emailField);
        add(new JLabel("手機號碼："));
        add(phoneField);
        add(new JLabel("使用者密碼："));
        add(passwordField);
        add(new JLabel());
        add(loginButton);
        add(new JLabel());
        add(messageLabel);

        loginButton.addActionListener(e -> attemptLogin());
    }

    private void attemptLogin() {
        String email = emailField.getText().trim();
        String phone = new String(phoneField.getPassword()).trim();
        String password = new String(passwordField.getPassword()).trim();

        if (email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            messageLabel.setText("請填寫所有欄位");
            return;
        }

        String url = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=UTC";
        String dbUsername = "MG07";
        String dbPassword = "D4NrtF";

        String sql = "SELECT userID, Name FROM user_Info " +
                     "WHERE Email = ? AND PhoneNumber = ? AND Password = ?";
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            pstmt.setString(2, phone);
            pstmt.setString(3, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int userID = rs.getInt("userID");
                    onSuccess.accept(userID);
                    dispose();
                } else {
                    messageLabel.setText("帳號、手機或密碼錯誤");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            messageLabel.setText("資料庫錯誤: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginForm form = new LoginForm(userID -> {
                JOptionPane.showMessageDialog(null, "登入成功，userID=" + userID);
            });
            form.setVisible(true);
        });
    }
}
