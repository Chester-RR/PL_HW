import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TaxiDetailFrame extends JFrame {
    // 資料庫連線參數
	private static final String URL =
		    "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";

    private static final String DB_USER = "MG07";
    private static final String DB_PASS = "D4NrtF";

    private final int groupID;          // 目前要顯示的行程群組
    private final int currentUserID;    // 目前登入者

    // 參與者表格
    private final DefaultTableModel participantModel;
    private final JTable participantTable;
    private final JButton confirmButton;

    // 留言板
    private final DefaultListModel<String> commentListModel;
    private final JList<String> commentList;
    private final JTextField commentField;
    private final JButton addCommentButton;

    public TaxiDetailFrame(int groupID, int currentUserID) {
        this.groupID       = groupID;
        this.currentUserID = currentUserID;

        setTitle("行程詳細 (Group " + groupID + ")");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        // 1. 參與者表格 (NORTH)
        String[] cols = { "暱稱", "電話", "Email" };
        participantModel = new DefaultTableModel(cols, 0);
        participantTable = new JTable(participantModel);
        JScrollPane partScroll = new JScrollPane(participantTable);
        partScroll.setPreferredSize(new Dimension(480, 120));
        add(partScroll, BorderLayout.NORTH);

        // 2. 留言列表 (CENTER)
        commentListModel = new DefaultListModel<>();
        commentList = new JList<>(commentListModel);
        JScrollPane commentScroll = new JScrollPane(commentList);
        commentScroll.setPreferredSize(new Dimension(480, 300));
        add(commentScroll, BorderLayout.CENTER);

        // 3. 底部區：加入行程 + 新增留言
        JPanel bottomPanel = new JPanel(new BorderLayout(5,5));

        // 3-1. 加入行程按鈕
        confirmButton = new JButton("加入此行程");
        bottomPanel.add(confirmButton, BorderLayout.NORTH);

        // 3-2. 留言輸入區
        JPanel commentInputPanel = new JPanel(new BorderLayout(5,5));
        commentField = new JTextField();
        addCommentButton = new JButton("新增留言");
        commentInputPanel.add(commentField, BorderLayout.CENTER);
        commentInputPanel.add(addCommentButton, BorderLayout.EAST);

        bottomPanel.add(commentInputPanel, BorderLayout.SOUTH);
        add(bottomPanel, BorderLayout.SOUTH);

        // 綁定動作 & 載入初始資料
        loadParticipantsFromDB();  // 撈同 groupID 的所有成員
        loadCommentsFromDB();      // 撈同 groupID 的所有留言

        confirmButton.addActionListener(e -> {
            addCurrentUserToGroup();
            loadParticipantsFromDB();  // 更新參與者列表
        });
        addCommentButton.addActionListener(e -> {
            addCommentToDB();
            loadCommentsFromDB();      // 更新留言列表
            commentField.setText("");
        });
    }

    /** 撈取 connection + user_Info，顯示所有此 groupID 的成員 */
    private void loadParticipantsFromDB() {
        String sql = """
            SELECT u.Name, u.PhoneNumber, u.Email
              FROM user_Info u
              JOIN connection c
                ON u.userID = c.userID
             WHERE c.groupID = ?
        """;
        try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, groupID);
            ResultSet rs = ps.executeQuery();

            participantModel.setRowCount(0);
            while (rs.next()) {
                participantModel.addRow(new Object[]{
                    rs.getString("Name"),
                    rs.getString("PhoneNumber"),
                    rs.getString("Email")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "載入參與者失敗: " + ex.getMessage(),
                "錯誤",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /** 將當前登入者加入 connection（同 groupID） */
    private void addCurrentUserToGroup() {
        String sql = "INSERT IGNORE INTO connection (groupID, userID) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, groupID);
            ps.setInt(2, currentUserID);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "加入此行程失敗: " + ex.getMessage(),
                "錯誤",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /** 撈取 taxi_comment 表中此 groupID 的所有留言 */
    private void loadCommentsFromDB() {
        String sql = """
            SELECT u.Name, c.commentText, c.createTime
              FROM taxi_comment c
              JOIN user_Info u
                ON c.userID = u.userID
             WHERE c.groupID = ?
             ORDER BY c.createTime
        """;
        try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, groupID);
            ResultSet rs = ps.executeQuery();

            commentListModel.clear();
            while (rs.next()) {
                Timestamp tm = rs.getTimestamp("createTime");
                String who = rs.getString("Name");
                String txt = rs.getString("commentText");
                commentListModel.addElement(
                    String.format("[%1$tF %1$tR] %2$s：%3$s", tm, who, txt)
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "載入留言失敗: " + ex.getMessage(),
                "錯誤",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /** 將新留言寫入 taxi_comment（並帶入同 groupID） */
    private void addCommentToDB() {
        String txt = commentField.getText().trim();
        if (txt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "留言不可為空", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "INSERT INTO taxi_comment (groupID, userID, commentText) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, groupID);
            ps.setInt(2, currentUserID);
            ps.setString(3, txt);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "新增留言失敗: " + ex.getMessage(),
                "錯誤",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
