class Person {
	private int userID;
    private String nickname;
    private String phone;
    private String email;

    public Person(int userID, String nickname, String phone, String email) {
    	this.userID = userID;
        this.nickname = nickname;
        this.phone = phone;
        this.email = email;
    }

    public String getNickname() { return nickname; }
    public String getPhone()    { return phone;    }
    public String getEmail()    { return email;    }
}
