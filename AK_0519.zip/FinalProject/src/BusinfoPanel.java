import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class BusinfoPanel extends JPanel {

	static class EstimateInfo {
		String Destination;
		Object EstimateTime;
		String StopName;
		long ArrivalTime;
	}

	public BusinfoPanel() {

		setLayout(new BorderLayout(10, 10));

		// ===== Tab 樣式字體統一 =====
		UIManager.put("TabbedPane.font", new Font("SansSerif", Font.BOLD, 14));

		// ===== 上方：公車專區 + 查詢按鈕 =====
		JPanel topPanel = new JPanel(new BorderLayout());
		topPanel.setBackground(new Color(240, 240, 240));
		topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		JLabel titleLabel = new JLabel("🚍 公車專區");
		titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
		titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

		JButton BusButton = new JButton("公車查詢");
		BusButton.setForeground(Color.WHITE);
		BusButton.setFont(new Font("SansSerif", Font.PLAIN, 14));
		BusButton.setFocusPainted(false);
		BusButton.setBackground(new Color(70, 130, 180));
		BusButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

		BusButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				bus_Info b = new bus_Info();
				b.setVisible(true);
			}
		});

		topPanel.add(titleLabel, BorderLayout.WEST);
		topPanel.add(BusButton, BorderLayout.EAST);

		// ===== 中央：主要 Tab 分頁 =====
		JTabbedPane busTabPane = new JTabbedPane();
		busTabPane.addTab("台北車站", createStationTab("MainStation"));
		busTabPane.addTab("動物園", createStationTab("TaipeiZoo"));
		busTabPane.addTab("市政府", createStationTab("CityHall"));

		add(topPanel, BorderLayout.NORTH);
		add(busTabPane, BorderLayout.CENTER);
	}

	public static JTabbedPane createStationTab(String stationName) {
		JTabbedPane subTabPane = new JTabbedPane();
		subTabPane.addTab("政大", createSubTabPanel(stationName, "政大"));
		subTabPane.addTab("政大一", createSubTabPanel(stationName, "政大一"));
		return subTabPane;
	}

	private static JPanel createSubTabPanel(String mainStation, String stopName) {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.WHITE);

		String[] columnNames = { "站點", "公車", "預估時間", "預估到達時間" };
		DefaultTableModel model = new DefaultTableModel(new Object[0][4], columnNames) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};

		JTable table = new JTable(model);
		table.setRowHeight(28);
		table.setFont(new Font("SansSerif", Font.BOLD, 14));
		table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
		table.getTableHeader().setBackground(new Color(230, 230, 230));
		table.setIntercellSpacing(new Dimension(10, 5));
		table.setShowGrid(false);
		table.setBackground(new Color(250, 250, 245));
		panel.add(new JScrollPane(table), BorderLayout.CENTER);

		fetchAndDisplayData(mainStation, stopName, table);
		new Timer(5000, e -> fetchAndDisplayData(mainStation, stopName, table)).start();

		table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
				if (!isSelected) {
					try {
						String estimateText = (String) table.getValueAt(row, 2);
						switch (estimateText) {
						case "已進站":
							comp.setBackground(new Color(255, 140, 0));
							break;
						case "進站中":
							comp.setBackground(new Color(255, 165, 60));
							break;
						case "將進站":
							comp.setBackground(new Color(255, 205, 145));
							break;
						default:
							comp.setBackground(new Color(255, 245, 230));
						}
					} catch (Exception e) {
						comp.setBackground(Color.WHITE);
					}
				}
				return comp;
			}
		});

		return panel;
	}

	private static void fetchAndDisplayData(String stationName, String stopKey, JTable table) {
		if (table.getModel().getRowCount() == 0) {
			table.setModel(new DefaultTableModel(new String[][] { { "載入中...", "載入中...", "載入中...", "載入中..." } },
					new String[] { "站點", "公車", "預估時間", "到達時間" }));
		}

		new SwingWorker<List<EstimateInfo>, Void>() {
			protected List<EstimateInfo> doInBackground() throws Exception {
				String urlString = "http://127.0.0.1:5000/";
				URL url = new URL(urlString);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");

				BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				StringBuilder jsonBuilder = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					jsonBuilder.append(line);
				}
				reader.close();

				Gson gson = new Gson();
				Map<String, Object> fullMap = gson.fromJson(jsonBuilder.toString(),
						new TypeToken<Map<String, Object>>() {
						}.getType());

				Object stationData = fullMap.get(stationName);
				if (stationData == null)
					return null;

				Map<String, List<EstimateInfo>> stopMap = gson.fromJson(gson.toJson(stationData),
						new TypeToken<Map<String, List<EstimateInfo>>>() {
						}.getType());
				return stopMap.get(stopKey);
			}

			protected void done() {
				try {
					List<EstimateInfo> list = get();
					DefaultTableModel tableModel;
					if (list == null || list.isEmpty()) {
						tableModel = new DefaultTableModel(new String[][] { { "無車次資料", "", "", "" } },
								new String[] { "站點", "公車", "預估時間", "預估到達時間" }) {
							public boolean isCellEditable(int row, int col) {
								return false;
							}
						};
					} else {
						list.removeIf(info -> getEstimateTimeValue(info.EstimateTime) < 0);
						list.sort(Comparator.comparingInt(info -> getEstimateTimeValue(info.EstimateTime)));

						String[][] data = new String[list.size()][4];
						long nowMillis = System.currentTimeMillis();
						SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

						for (int i = 0; i < list.size(); i++) {
							EstimateInfo info = list.get(i);
							data[i][0] = info.StopName;
							data[i][1] = info.Destination;
							data[i][2] = formatTime(info.EstimateTime);
							long arrivalMillis = nowMillis + getEstimateTimeValue(info.EstimateTime) * 1000;
							data[i][3] = sdf.format(new Date(arrivalMillis));
						}

						tableModel = new DefaultTableModel(data, new String[] { "站點", "公車", "預估時間", "預估到達時間" }) {
							public boolean isCellEditable(int row, int col) {
								return false;
							}
						};
					}
					table.setModel(tableModel);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}.execute();
	}

	private static int getEstimateTimeValue(Object estimateTime) {
		try {
			if (estimateTime == null)
				return -1;
			if (estimateTime instanceof Number) {
				return ((Number) estimateTime).intValue();
			} else if (estimateTime instanceof String) {
				return Integer.parseInt((String) estimateTime);
			}
		} catch (Exception e) {
			return -1;
		}
		return -1;
	}

	private static String formatTime(Object estimateTime) {
		int time = getEstimateTimeValue(estimateTime);
		if (time == 0)
			return "已進站";
		if (time < 60)
			return "進站中";
		if (time < 180)
			return "將進站";
		return (time / 60) + " 分鐘 (" + (time / 60) + " mins)";
	}
}