import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;

public class TaxiDetailFrame extends JFrame {
	// 資料庫連線參數
	private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG07?useSSL=false&serverTimezone=Asia/Taipei";
	private static final String DB_USER = "MG07";
	private static final String DB_PASS = "D4NrtF";

	private final int groupID;
	private final int currentUserID;

	private final DefaultTableModel participantModel;
	private final JTable participantTable;
	private final JButton confirmButton;

	private final DefaultListModel<String> commentListModel;
	private final JList<String> commentList;
	private final JTextField commentField;
	private final JButton addCommentButton;

	public TaxiDetailFrame(int groupID, int currentUserID) {
		this.groupID = groupID;
		this.currentUserID = currentUserID;
		new Timer(10000, e -> {
			loadParticipantsFromDB();
			loadCommentsFromDB();
		}).start();

		setTitle("行程詳細 (Group " + groupID + ")");
		setSize(500, 600);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout(10, 10));

		// 1. 參與者表格 (NORTH)
		String[] cols = { "暱稱", "電話", "Email" };
		participantModel = new DefaultTableModel(cols, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				// 禁止所有儲存格編輯
				return false;
			}
		};
		participantTable = new JTable(participantModel);
		participantTable.setEnabled(false); // 鎖住無法選取或編輯
		JScrollPane partScroll = new JScrollPane(participantTable);
		partScroll.setPreferredSize(new Dimension(480, 120));
		add(partScroll, BorderLayout.NORTH);

		// 2. 留言列表 (CENTER)
		commentListModel = new DefaultListModel<>();
		commentList = new JList<>(commentListModel);
		JScrollPane commentScroll = new JScrollPane(commentList);
		commentScroll.setPreferredSize(new Dimension(480, 300));
		add(commentScroll, BorderLayout.CENTER);

		// 3. 底部區：加入行程 + 新增留言
		JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
		confirmButton = new JButton("加入此行程");
		bottomPanel.add(confirmButton, BorderLayout.NORTH);

		JPanel commentInputPanel = new JPanel(new BorderLayout(5, 5));
		commentField = new JTextField();
		addCommentButton = new JButton("新增留言");
		commentInputPanel.add(commentField, BorderLayout.CENTER);
		commentInputPanel.add(addCommentButton, BorderLayout.EAST);
		bottomPanel.add(commentInputPanel, BorderLayout.SOUTH);
		add(bottomPanel, BorderLayout.SOUTH);

		loadParticipantsFromDB();
		loadCommentsFromDB();

		confirmButton.addActionListener(e -> {
			try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS)) {
				// 1. 檢查是否已加入
				String checkJoinSql = "SELECT COUNT(*) FROM connection WHERE groupID = ? AND userID = ?";
				try (PreparedStatement ps = conn.prepareStatement(checkJoinSql)) {
					ps.setInt(1, groupID);
					ps.setInt(2, currentUserID);
					try (ResultSet rs = ps.executeQuery()) {
						rs.next();
						if (rs.getInt(1) > 0) {
							JOptionPane.showMessageDialog(this, "您已經加入該行程", "提示", JOptionPane.INFORMATION_MESSAGE);
							return;
						}
					}
				}
				// 2. 檢查是否已滿
				String checkFullSql = "SELECT t.MaxPeople, COUNT(c.userID) AS cnt " + "FROM taxi_Info t "
						+ "LEFT JOIN connection c ON t.groupID = c.groupID " + "WHERE t.groupID = ? "
						+ "GROUP BY t.MaxPeople";
				try (PreparedStatement ps = conn.prepareStatement(checkFullSql)) {
					ps.setInt(1, groupID);
					try (ResultSet rs = ps.executeQuery()) {
						if (rs.next()) {
							int maxPeople = rs.getInt("MaxPeople");
							int currentCount = rs.getInt("cnt");
							if (currentCount >= maxPeople) {
								JOptionPane.showMessageDialog(this, "此行程人數已滿，無法加入", "提示", JOptionPane.WARNING_MESSAGE);
								return;
							}
						}
					}
				}
				// 3. 真正加入
				String insertSql = "INSERT INTO connection (groupID, userID) VALUES (?, ?)";
				try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
					ps.setInt(1, groupID);
					ps.setInt(2, currentUserID);
					ps.executeUpdate();
				}
				// 4. 刷新並提示
				loadParticipantsFromDB();
				JOptionPane.showMessageDialog(this, "加入成功！", "Info", JOptionPane.INFORMATION_MESSAGE);

			} catch (SQLException ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(this, "加入此行程失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
			}
		});
		addCommentButton.addActionListener(e -> {
			addCommentToDB();
			loadCommentsFromDB();
			commentField.setText("");
		});
	}

	private void loadParticipantsFromDB() {
		String sql = "SELECT u.Name, u.PhoneNumber, u.Email FROM user_Info u JOIN connection c "
				+ "ON u.userID = c.userID WHERE c.groupID = ?";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ResultSet rs = ps.executeQuery();
			participantModel.setRowCount(0);
			while (rs.next()) {
				participantModel.addRow(
						new Object[] { rs.getString("Name"), rs.getString("PhoneNumber"), rs.getString("Email") });
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "載入參與者失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void addCurrentUserToGroup() {
		String sql = "INSERT IGNORE INTO connection (groupID, userID) VALUES (?, ?)";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "加入此行程失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void loadCommentsFromDB() {
		String sql = "SELECT u.Name, c.commentText, c.createTime FROM taxi_comment c JOIN user_Info u "
				+ "ON c.userID = u.userID WHERE c.groupID = ? ORDER BY c.createTime";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ResultSet rs = ps.executeQuery();
			commentListModel.clear();
			while (rs.next()) {
				Timestamp tm = rs.getTimestamp("createTime");
				commentListModel.addElement(String.format("[%1$tF %1$tR] %2$s：%3$s", tm, rs.getString("Name"),
						rs.getString("commentText")));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "載入留言失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void addCommentToDB() {
		String txt = commentField.getText().trim();
		if (txt.isEmpty()) {
			JOptionPane.showMessageDialog(this, "留言不可為空", "提示", JOptionPane.WARNING_MESSAGE);
			return;
		}
		String sql = "INSERT INTO taxi_comment (groupID, userID, commentText) VALUES (?, ?, ?)";
		try (Connection conn = DriverManager.getConnection(URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, groupID);
			ps.setInt(2, currentUserID);
			ps.setString(3, txt);
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "新增留言失敗: " + ex.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
		}
	}
}
